"""
Model-Free Control Barrier Function Implementation
Based on: "Safety via Control Barrier Functions Synthesized from Ultra-Local Models"

Implements GP-based barrier learning and HOCBF constraints using estimated ULM parameters.
"""
import cupy as cp
import numpy as np
from qpsolvers import solve_qp


class ModelFreeCBF:
    """
    Model-Free CBF using GP barriers and MIMO ULM dynamics estimation.
    """

    def __init__(self, dt, u_min, u_max, r_max, r_min_obstacle, length_scale, sigma_f, lambda_0, lambda_1, c_q):
        """
        Args:
            dt: Sampling period
            u_min: Minimum control input [v_min, ω_min]
            u_max: Maximum control input [v_max, ω_max]
            r_max: Maximum LiDAR range
            r_min_obstacle: Only consider obstacles closer than this
            length_scale: GP kernel length scale
            sigma_f: GP signal variance
            lambda_0, lambda_1: HOCBF parameters (Section II-C of paper)
            c_q: Confidence quantile for safety margin (e.g., 2.0 for 2-sigma)
        """
        self.dt = dt
        self.u_min = cp.array(u_min)
        self.u_max = cp.array(u_max)
        self.r_max = r_max
        self.r_min_obstacle = r_min_obstacle
        self.length_scale = length_scale
        self.sigma_f = sigma_f
        self.lambda_0 = lambda_0
        self.lambda_1 = lambda_1
        self.c_q = c_q

        # Obstacle points (set by set_obstacles)
        self.obstacle_points = None
        self.N = 0

        # Cache for GP computations (speeds up repeated queries)
        self._K_inv_cache = None
        self._alpha_cache = None

        # Pre-allocate arrays for QP to avoid repeated numpy conversions
        self._P_qp = np.diag([10.0, 0.1])
        self._G_template = np.zeros((5, 2), dtype=np.float64)
        self._G_template[1:3, :] = np.eye(2)
        self._G_template[3:5, :] = -np.eye(2)
        self._h_qp = np.zeros(5, dtype=np.float64)
        self._q_qp = np.zeros(2, dtype=np.float64)

    def set_obstacles(self, ranges, angles):
        """
        Process LiDAR data to extract obstacle points in robot frame.

        Args:
            ranges: CuPy array of distances
            angles: CuPy array of angles (radians)
        """
        ranges = cp.asarray(ranges)
        angles = cp.asarray(angles)

        # Filter by range - only consider close obstacles!
        mask = (ranges < self.r_min_obstacle) & (ranges > 0.1)
        filtered_ranges = ranges[mask]
        filtered_angles = angles[mask]

        # Convert to Cartesian (robot frame, x forward, y left)
        # Note: Adjust sign based on your coordinate convention
        x = filtered_ranges * cp.cos(filtered_angles)
        y = filtered_ranges * cp.sin(filtered_angles)

        # No additional downsampling here - already sparse from node
        self.obstacle_points = cp.column_stack((x, -y))  # Adjust y sign if needed
        self.N = len(self.obstacle_points)

        # Precompute and cache K_inv for this obstacle set (major speedup!)
        if self.N > 0:
            Y = -cp.ones((self.N, 1))
            K = self.rbf_kernel(self.obstacle_points, self.obstacle_points)
            self._K_inv_cache = cp.linalg.inv(K + 1e-6 * cp.eye(self.N))
            self._alpha_cache = self._K_inv_cache @ (Y - 1.0)
        else:
            self._K_inv_cache = None
            self._alpha_cache = None

    def rbf_kernel(self, X1, X2):
        """
        RBF kernel: k(x, x') = σ_f² exp(-||x - x'||² / (2 ℓ²))

        Args:
            X1: (N1, d) array
            X2: (N2, d) array

        Returns:
            K: (N1, N2) kernel matrix
        """
        sqdist = cp.sum(X1**2, axis=1, keepdims=True) + \
                 cp.sum(X2**2, axis=1) - 2 * (X1 @ X2.T)
        return self.sigma_f**2 * cp.exp(-0.5 * sqdist / self.length_scale**2)

    def get_barrier_and_variance(self, p):
        """
        Compute GP posterior mean and variance for barrier at point p.

        h(p) = 1 + k(p, P)^T K^{-1} (Y - 1)

        Where Y = -ones (obstacles labeled as -1), and we shift to make
        default value (far from obstacles) equal to +1.

        Args:
            p: Query point [x, y] (list or array)

        Returns:
            h: Barrier value (scalar)
            sigma_sq: GP posterior variance (scalar)
        """
        if self.N == 0:
            return 1.0, 0.0  # No obstacles

        p = cp.array(p).reshape(1, 2)

        # Use cached K_inv and alpha (huge speedup!)
        k_star = self.rbf_kernel(p, self.obstacle_points)  # (1, N)

        # GP posterior mean (shifted) using cached alpha
        h = 1.0 + float((k_star @ self._alpha_cache).reshape(-1)[0])

        # GP posterior variance (Eq. 6 in paper)
        k_ss = self.rbf_kernel(p, p)[0, 0]
        sigma_sq = float((k_ss - k_star @ self._K_inv_cache @ k_star.T).reshape(-1)[0])

        return h, sigma_sq

    def get_gradient(self, p):
        """
        Compute gradient of GP barrier: ∇h(p)

        From Eq. (5) in paper:
        ∇h(p) = Σ_j α_j k(p, p_j) (p_j - p) / ℓ²

        where α = K^{-1}(Y - 1)

        Args:
            p: Query point [x, y]

        Returns:
            grad_h: Gradient [∂h/∂x, ∂h/∂y] (2D CuPy array)
        """
        if self.N == 0:
            return cp.zeros(2)

        p = cp.array(p).reshape(1, 2)

        # Use cached alpha (huge speedup!)
        # k(p, p_j) for all j
        k_star = self.rbf_kernel(p, self.obstacle_points)  # (1, N)

        # Differences: (p_j - p) for all j
        diff = self.obstacle_points - p  # (N, 2)

        # Gradient: Σ_j α_j k(p, p_j) (p_j - p) / ℓ²
        grad_h = (k_star.T * self._alpha_cache).T @ diff / self.length_scale**2  # (1, 2)

        return grad_h.flatten()

    def compute_safety_margin(self, P, u_max):
        """
        Compute safety margin σ_k from EKF covariance.

        From Eq. (13) in paper:
        σ̄²_{η,k} = max_{u ∈ U} ℓ^T_{η,k}(u) P^q_k ℓ_{η,k}(u)

        where ℓ_{η,k}(u) = [λ_0 λ_1, λ_0+λ_1, 1, u^T]^T

        Args:
            P: EKF covariance matrix (CuPy array)
            u_max: Maximum control input (for worst-case margin)

        Returns:
            sigma: Safety margin c_q * σ̄_{η,k}
        """
        # Evaluate at worst case: u = u_max
        u_wc = cp.asarray(self.u_max)
        P = cp.asarray(P)

        ell = cp.array([
            self.lambda_0 * self.lambda_1,
            self.lambda_0 + self.lambda_1,
            1.0,
            float(u_wc[0]),
            float(u_wc[1])
        ])

        sigma_sq = float(ell @ P @ ell)
        sigma_bar = float(cp.sqrt(cp.maximum(sigma_sq, 0.0)))

        # Clamp safety margin to prevent infeasibility during EKF convergence
        sigma = float(self.c_q * sigma_bar)
        sigma_max = 0.05  # Maximum safety margin - very small to ensure feasibility
        return min(sigma, sigma_max)

    def compute_safe_control(self, u_ref, q_hat, qdot_hat, F_q_hat, B_q_hat, P, v_current=1.0,
                              use_feasibility_precheck=True, use_slack_fallback=True):
        """
        Solve CLF-CBF QP to compute safe control with velocity-dependent safety.

        From Eq. (9) in paper:
        B̂_q,k u ≥ -F̂_q,k - (λ_0 + λ_1)q̇̂_k - λ_0 λ_1 q̂_k + σ_k

        QP formulation:
            minimize    ||u - u_ref||²
            subject to  B̂_q,k u ≥ r_k  (CBF constraint)
                        u_min ≤ u ≤ u_max  (input bounds)

        Two fixes vs. the original implementation, both addressing the
        infeasibility cascade seen on hardware (repeated infeasible solves ->
        B_q estimate drifts to its floor -> even more infeasible), and both
        aimed at favoring steering over stopping when a fix is needed:

        1. FEASIBILITY PRECHECK (use_feasibility_precheck): before solving,
           use check_feasibility() (Lemma 1) to predict infeasibility from
           the current estimates alone. If infeasible, pre-emptively reduce
           u_ref's velocity component proportional to the shortfall, then
           re-check. This tends to avoid needing the solver's brake fallback
           in the first place -- and critically leaves ω (steering) untouched,
           so avoidance authority isn't sacrificed just because the velocity
           term alone can't satisfy the constraint.

        2. SLACK FALLBACK (use_slack_fallback): if the exact (hard-constraint)
           QP is still infeasible after the precheck, don't return a blind
           [u_min, 0] brake. Instead solve a relaxed QP that allows a
           penalized constraint violation and returns the best-effort control
           the actuators can physically produce, plus how much the constraint
           had to be violated by (the `slack` return value). Because the
           relaxed solve searches the full box (not just velocity), it will
           use whatever steering authority is available rather than always
           collapsing to a straight-line brake.

        Args:
            u_ref: Reference control [v_ref, ω_ref]
            q_hat: Estimated barrier value
            qdot_hat: Estimated barrier derivative
            F_q_hat: Estimated lumped disturbance
            B_q_hat: Estimated input sensitivity [B_v, B_ω]
            P: EKF covariance matrix
            v_current: Current velocity (for velocity-dependent scaling)
            use_feasibility_precheck: enable fix (1) above
            use_slack_fallback: enable fix (2) above

        Returns:
            u_safe: Safe control input [v, ω]
            feasible: True if the hard CBF constraint was satisfied exactly
                (i.e. no slack was needed). False means the returned control
                is a best-effort / relaxed solution.
            slack: amount of constraint violation in the returned solution
                (0.0 when feasible is True). Useful as an early-warning
                signal / for logging infeasibility streaks.
        """
        # Ensure inputs are CuPy arrays
        u_ref = cp.asarray(u_ref)
        B_q_hat = cp.asarray(B_q_hat)

        # Compute safety margin with velocity scaling
        # Higher velocity → larger safety margin (stopping distance ∝ v²)
        v_scale = 1.0 + 0.5 * (v_current / float(self.u_max[0]))
        sigma_k = self.compute_safety_margin(P, self.u_max) * v_scale

        # HOCBF RHS (Eq. 10 in paper)
        r_k = -F_q_hat - (self.lambda_0 + self.lambda_1) * qdot_hat - \
              self.lambda_0 * self.lambda_1 * q_hat + sigma_k

        # QP formulation - use pre-allocated arrays for speed
        # Convert CuPy to NumPy once using .get()
        u_ref_np = u_ref.get() if hasattr(u_ref, 'get') else np.asarray(u_ref, dtype=np.float64)
        B_q_np = B_q_hat.get() if hasattr(B_q_hat, 'get') else np.asarray(B_q_hat, dtype=np.float64)
        u_max_np = self.u_max.get() if hasattr(self.u_max, 'get') else np.asarray(self.u_max, dtype=np.float64)
        u_min_np = self.u_min.get() if hasattr(self.u_min, 'get') else np.asarray(self.u_min, dtype=np.float64)

        # --- FIX 1: feasibility precheck (Lemma 1) ---
        if use_feasibility_precheck:
            feasible_pre, M_k, r_k_check = self.check_feasibility(
                q_hat, qdot_hat, F_q_hat, B_q_hat, sigma_k, return_details=True)
            if not feasible_pre:
                shortfall = r_k_check - M_k
                # Reduce only the velocity component of u_ref, proportional to
                # the shortfall; leave omega alone so steering-based avoidance
                # is never suppressed by this precheck.
                v_cut = max(0.0, u_ref_np[0] - shortfall * 0.5)
                u_ref_np = np.array([v_cut, u_ref_np[1]])

        # Reuse pre-allocated arrays
        np.dot(self._P_qp, -u_ref_np, out=self._q_qp)  # Linear term: -W @ u_ref

        # Update G matrix (only first row changes)
        self._G_template[0, :] = -B_q_np

        # Update h vector
        self._h_qp[0] = -r_k
        self._h_qp[1] = u_max_np[0]
        self._h_qp[2] = u_max_np[1]
        self._h_qp[3] = -u_min_np[0]
        self._h_qp[4] = -u_min_np[1]

        # Solve QP - use OSQP for speed (much faster than clarabel for small problems)
        try:
            sol = solve_qp(
                P=self._P_qp,
                q=self._q_qp,
                G=self._G_template,
                h=self._h_qp,
                solver='osqp',
                eps_abs=1e-4,  # Relaxed tolerance for speed
                eps_rel=1e-4,
                max_iter=100,  # Limit iterations
                polish=False,  # Skip polishing step for speed
                verbose=False
            )

            if sol is None:
                print(f'\n=== QP INFEASIBLE ===')
                print(f'CBF constraint: -B_q @ u <= {float(-r_k):.4f}')
                print(f'  B_q = {B_q_np}')
                print(f'  Breakdown: -F_q={-F_q_hat:.3f}, -(λ0+λ1)q̇={-(self.lambda_0+self.lambda_1)*qdot_hat:.3f}, -λ0λ1q={-self.lambda_0*self.lambda_1*q_hat:.3f}, σ={sigma_k:.3f}')
                print(f'State: q={q_hat:.3f}, q̇={qdot_hat:.3f}')
                print(f'ULM: F_q={F_q_hat:.3f}, B_q={B_q_np}')
                print(f'Control bounds: v∈[{u_min_np[0]:.2f}, {u_max_np[0]:.2f}], ω∈[{u_min_np[1]:.2f}, {u_max_np[1]:.2f}]')
                print(f'Max achievable: B_q @ u_max = {float(B_q_np[0]*u_max_np[0] + B_q_np[1]*u_max_np[1]):.3f}')

                # --- FIX 2: slack fallback instead of a blind brake ---
                if use_slack_fallback:
                    u_safe, slack = self.solve_qp_with_slack(
                        u_ref_np, B_q_np, r_k, u_min_np, u_max_np)
                    print(f'Slack fallback: u={u_safe}, remaining violation={slack:.4f}')
                    print(f'=====================\n')
                    return u_safe, False, slack

                print(f'=====================\n')
                # Return safe fallback (original behavior)
                return [float(u_min_np[0]), 0.0], False, float('nan')

            return [float(sol[0]), float(sol[1])], True, 0.0

        except Exception as e:
            print(f'QP solve exception: {e}')
            print(f'  q_hat={q_hat:.3f}, qdot_hat={qdot_hat:.3f}')
            print(f'  F_q_hat={F_q_hat:.3f}, B_q_hat={B_q_np}')
            print(f'  r_k={float(r_k):.3f}, sigma_k={sigma_k:.3f}')

            if use_slack_fallback:
                try:
                    u_safe, slack = self.solve_qp_with_slack(
                        u_ref_np, B_q_np, r_k, u_min_np, u_max_np)
                    return u_safe, False, slack
                except Exception as e2:
                    print(f'Slack fallback also failed: {e2}')

            # Return safe fallback
            return [float(u_min_np[0]), 0.0], False, float('nan')

    def solve_qp_with_slack(self, u_ref_np, B_q_np, r_k, u_min_np, u_max_np,
                             slack_weight=1000.0, n_line_search=40):
        """
        Fallback QP solve that relaxes the CBF constraint with a slack variable
        instead of returning a hard-brake fallback when the exact QP is infeasible.

        Solves (approximately, via 1D line search since the decision space is
        just 2D and box-constrained -- exact for this problem shape):
            minimize    ||u - u_ref||_P^2 + slack_weight * s^2
            subject to  B_q @ u >= r_k - s,  s >= 0
                        u_min <= u <= u_max

        This never fails: if the box constraint's best case for satisfying the
        CBF row is still short of r_k, it returns the control that gets as
        close as possible (minimizes remaining violation) while respecting the
        tracking cost, plus how much slack (constraint violation) was needed.

        Searches along the segment from u_ref to the box corner that best
        satisfies the constraint (u_min/u_max chosen per-axis by the sign of
        B_q), so it naturally uses whichever of v or ω has authority left
        rather than only ever cutting velocity.

        Returns:
            u_safe: [v, ω] best-effort control
            slack: amount of constraint violation remaining (0.0 if fully satisfied)
        """
        u_ref_np = np.asarray(u_ref_np, dtype=np.float64)
        a = -np.asarray(B_q_np, dtype=np.float64)  # a @ u <= b form
        b = -float(r_k)
        u_min_np = np.asarray(u_min_np, dtype=np.float64)
        u_max_np = np.asarray(u_max_np, dtype=np.float64)
        P_diag = np.diag(self._P_qp) if self._P_qp.ndim == 2 else self._P_qp

        # Point in the box that minimizes a@u (best case for satisfying the constraint)
        u_best_for_constraint = np.where(a >= 0, u_min_np, u_max_np)

        direction = u_best_for_constraint - u_ref_np
        ts = np.linspace(0.0, 1.0, n_line_search)
        best_t, best_cost = 0.0, np.inf
        for t in ts:
            u_t = np.clip(u_ref_np + t * direction, u_min_np, u_max_np)
            violation = max(0.0, a @ u_t - b)
            track_cost = 0.5 * np.sum(P_diag * (u_t - u_ref_np) ** 2)
            cost = track_cost + slack_weight * violation ** 2
            if cost < best_cost:
                best_cost, best_t = cost, t

        u_sol = np.clip(u_ref_np + best_t * direction, u_min_np, u_max_np)
        slack = max(0.0, a @ u_sol - b)
        return [float(u_sol[0]), float(u_sol[1])], float(slack)

    def check_feasibility(self, q_hat, qdot_hat, F_q_hat, B_q_hat, sigma_k, return_details=False):
        """
        Check if CBF QP is feasible (Lemma 1 in paper).

        Feasibility condition:
        M_k ≥ r_k

        where M_k = Σ_{j: [a_k]_j ≥ 0} [a_k]_j [u_max]_j + Σ_{j: [a_k]_j < 0} [a_k]_j [u_min]_j
        and a_k = B̂_q,k

        Args:
            q_hat, qdot_hat, F_q_hat, B_q_hat: EKF estimates
            sigma_k: Safety margin
            return_details: if True, also return (M_k, r_k) so callers can
                compute how large the shortfall is (used for pre-emptive
                velocity reduction before the QP is even solved).

        Returns:
            feasible: Boolean
            (M_k, r_k): only if return_details=True
        """
        B_q_hat = cp.array(B_q_hat)
        r_k = -F_q_hat - (self.lambda_0 + self.lambda_1) * qdot_hat - \
              self.lambda_0 * self.lambda_1 * q_hat + sigma_k

        M_k = 0.0
        for j in range(len(B_q_hat)):
            if float(B_q_hat[j]) >= 0:
                M_k += float(B_q_hat[j]) * float(self.u_max[j])
            else:
                M_k += float(B_q_hat[j]) * float(self.u_min[j])

        feasible = float(M_k) >= float(r_k)
        if return_details:
            return feasible, float(M_k), float(r_k)
        return feasible
